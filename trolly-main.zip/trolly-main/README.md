---
cover: .gitbook/assets/image_processing20210615-10726-1lo7r7z.png
coverY: 28.867574257425744
---

# What Is Trolly.in?

## Our Vision

{% hint style="info" %}
**Good to know:** a good vision statement shows the long-term goals of the company without getting too deep into strategy, implementation, or product specifics.
{% endhint %}

## Trolly is the top on-demand grocery delivery platform based in the Goa developed by top ranked & 10 year Old expertise  Ecommerce Development Firm named Kharedi Ecommerce.&#x20;

It's a concept of centralized delivery for all quick delivery needs by providing shopping platform and seamless integration with thirdparty apps to deliver your orders in little as an hour. It is a technology-driven hyperlocal business that is making grocery, Food and medicine shopping, pickup and drop parcel in the India as convenient as possible.&#x20;

{% hint style="info" %}
**Good to know:** company values are statements about how you approach work; how you treat colleagues, customers and users; and what your company stands for.
{% endhint %}
