# Table of contents

## The Company

* [What Is Trolly.in?](README.md)
* [Customer Segment!](the-company/customer-segment.md)
* [Revenue Model](the-company/revenue-model.md)
* [User Engagement](the-company/user-engagement.md)
* [Trolly: How Does It Find Customers?](the-company/trolly-how-does-it-find-customers.md)

## Reach us

* [Reg. Address](reach-us/reg.-address.md)
