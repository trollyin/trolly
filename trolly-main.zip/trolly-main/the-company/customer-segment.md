---
cover: ../.gitbook/assets/brand.jpg
coverY: 0
---

# Customer Segment!

{% hint style="info" %}
**Good to know:** an employee directory can be a great way to help new folks get familiar with everyone they're going to be working with.
{% endhint %}

## User

![](../.gitbook/assets/60minjpg.jpg)

###

* Users can order their groceries using the Trolly App or directly through the Website [https://trolly.in.](https://trolly.in)
* They can directly pay through the app by using an online payment option or opt for Cash on Delivery or Pay on Delivery using UPI.
* Users can place a order from various available option like order from N**ear by** shops for Cake, Cosmetics, Fruits, Vegetables etc, Order Groceries from **Grocery** section for 20 minutes Grocery delivery, Order for Medicine using a Prescription upload or shop for medical item in **Medical** Section.

![](../.gitbook/assets/Mockup-menu.png)

* Users can also place order via call to our delivery personnel.

{% hint style="info" %}
**Good to know:** Encourage employees to write a succinct bio that can help new hires learn about them and how they like to work.
{% endhint %}

## Delivery Boy

![](../.gitbook/assets/promo.png)

###

* Delivery Boys get the orders placed on their phones with sound notification.
* Delivery boys are assigned to location and dark store. They manually pick up the orders and deliver them to the user address.
* The delivery boys get paid based on their salary basis + Petrol Charges + Internet Charges + Delivery Commission +  tips from the customers if any.

{% hint style="info" %}
**Good to know:** Encourage employees to write a succinct bio that can help new hires learn about them and how they like to work.
{% endhint %}

## Store



![](../.gitbook/assets/Features-list-for-app-like-dija.jpg)

###



* Trolly has a tie-up with General Stores, Fruits and Vegetable Vendors,  Supermarkets and Medical Stores in major cities.&#x20;

{% hint style="info" %}
**Good to know:** Encourage employees to write a succinct bio that can help new hires learn about them and how they like to work.
{% endhint %}
