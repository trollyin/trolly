# User Engagement

## Coupon Code

Trolly has a unique feature, all the user has their own coupon code which they can use it for self or share it with friends  to promote the product of his choice, any one who use the coupon to buy, he or she will get a specific discount as well as the coupon code owner will get predefined commission  in percentage on total  order value. &#x20;

Apart from this trolly.in has its own Coupon in Percentage or Flat rate for users.&#x20;

User has option to apply its referred coupon by friend or generally available coupon on checkout whichever he/she find with good discount.

## Commission&#x20;

![](<../.gitbook/assets/refer a friens2.png>)



:gift:  Refer a Friend and Earn Rs. 50 to 100/- instantly credited to user wallet which can be used for future purchases.

:gift:  Signup and Earn Rs. 20 to 100 for new user - instantly credited to user wallet which can be used for future purchases.

:gift:  Earn 1% commission on purchased made by referral for 1 year ( Subjected to change the term without prior notice ).

:gift:  Get 1% commission on purchased made using a  user coupon code to promote product of their choice. Every user will be having its own coupon code type of discount.&#x20;





## Signup Bonus

New users will get Rs.20 to Rs.100, ( depends on offer available but minimum of Rs. 20/- ) into his wallet which he can redeem which making payment.



## Cashback offer

Customer loyalty by returning a percentage of the order value to the wallet.
