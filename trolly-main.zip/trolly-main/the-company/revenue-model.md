# Revenue Model

## Delivery Fees

Store owner can set their delivery charges in kilometer basis or flat rate basis, example Flat of Rs. 20 or Rs.8 per kilometer distance from store to user.  Store owner has to pay delivery fee on each order which is the **flat Rs.5/- per order delivered** regardless of whatever delivery charges you have set.

This is the only commission proposed by trolly.in which will be consider as a revenue to the trolly.in

Payment of **Rs.5 X Number of Deliveries** for the month shall be paid to to M/s trolly.in on or before 5th of Every month.

## Commission from  Dark Store&#x20;

Dark store are considered to be the **fulfillment center dedicated to rapid online order fulfillment which will be one for the selected area.**

2% commission on total order will be charged to fund our Refer and Earn model, which is considered to be a cost to marketing. We have multiple user engagement strategy and marketing strategy as mention below.&#x20;

2% commission shall be settled every week by the dark store.

![](../.gitbook/assets/darkstore.jpg)
