# Trolly: How Does It Find Customers?

**There are various ways in which trolly.in is receiving regular customers. The ways are mentioned below:**

People are getting the desired results from the services of trolly, which helps them get great word of mouth publicity.

Trolly gives the first delivery free to customers, which helps them see and feel the ease and convenience of the service.

Trolly has great internet and social media marketing.&#x20;

There are various offers going-on on the app which help them bind a customer with them. These happy customers eventually create word of mouth publicity.
